Open the Hotel Details.html in Chrome or Firefox.

To see the webpage as in a Mobile,

In chrome, just open the developer tools by Right-click menu > Inspect element and click on 'Toggle Device toolbar' btton at the top-left part of the developer tools console.

Select different devices from the list, to view the responsiveness.
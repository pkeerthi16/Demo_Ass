import React from 'react';
import RoomForm from './views/RoomForm';

function App() {
  return (
      <RoomForm/>
  );
}

export default App;

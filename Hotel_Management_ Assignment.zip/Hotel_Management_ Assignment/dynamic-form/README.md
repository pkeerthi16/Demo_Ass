To setup project (Install dependencies),

Run `npm install` or `yarn install`

To run the development server,

Run `npm run start` or `yarn start`

To run the tests,

Run `npm run test` or `yarn test`

Note: Local storage is used to store the state on form submit to pre-populate the fields on reload.